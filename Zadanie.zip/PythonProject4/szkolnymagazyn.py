

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QAbstractItemView, QMessageBox

import ast
import re
import sys
from dataclasses import asdict, dataclass
from datetime import date, datetime
from pathlib import Path

PLIK_DANYCH = Path(__file__).resolve().with_name("zdarzenia.txt")


@dataclass
class Zdarzenie:
    id: int
    typ: str
    kategoria: str
    model: str
    osoba: str
    miejsce: str
    data: str
    status: str = "Otwarte"

    def na_slownik(self):
        return asdict(self)

    @classmethod
    def ze_slownika(cls, dane):
        return cls(
            id=int(dane["id"]),
            typ=dane["typ"],
            kategoria=dane["kategoria"],
            model=dane["model"],
            osoba=dane["osoba"],
            miejsce=dane["miejsce"],
            data=dane["data"],
            status=dane.get("status", "Otwarte"),
        )


class RepozytoriumZdarzen:
    def __init__(self, sciezka):
        self.sciezka = Path(sciezka)
        self.zdarzenia = self.wczytaj()

    def wczytaj(self):
        if not self.sciezka.exists():
            return []

        try:
            with self.sciezka.open("r", encoding="utf-8") as plik:
                dane = ast.literal_eval(plik.read())
            return [Zdarzenie.ze_slownika(element) for element in dane]
        except (OSError, SyntaxError, ValueError, KeyError, TypeError):
            return []

    def zapisz(self):
        with self.sciezka.open("w", encoding="utf-8") as plik:
            dane = [zdarzenie.na_slownik() for zdarzenie in self.zdarzenia]
            plik.write(repr(dane))

    def dodaj(self, zdarzenie):
        self.zdarzenia.append(zdarzenie)
        self.zapisz()

    def znajdz(self, identyfikator):
        return next(
            (zdarzenie for zdarzenie in self.zdarzenia
             if zdarzenie.id == identyfikator),
            None,
        )

    def nastepne_id(self):
        return max((zdarzenie.id for zdarzenie in self.zdarzenia), default=0) + 1

    def filtruj(self, typ=None, kategoria=None, status=None):
        wynik = self.zdarzenia

        if typ:
            wynik = [
                zdarzenie for zdarzenie in wynik
                if zdarzenie.typ.casefold() == typ.casefold()
            ]

        if kategoria:
            wynik = [
                zdarzenie for zdarzenie in wynik
                if zdarzenie.kategoria.casefold() == kategoria.casefold()
            ]

        if status:
            wynik = [
                zdarzenie for zdarzenie in wynik
                if zdarzenie.status.casefold() == status.casefold()
            ]

        return sorted(
            wynik,
            key=lambda zdarzenie: (zdarzenie.data, zdarzenie.id),
            reverse=True,
        )


class Dopasowywacz:
    @staticmethod
    def normalizuj(tekst):
        return re.sub(r"\s+", " ", tekst.strip()).casefold()

    def punkty(self, wydanie, zwrot):
        if wydanie.kategoria.casefold() != zwrot.kategoria.casefold():
            return 0

        punkty = 2

        if self.normalizuj(wydanie.model) == self.normalizuj(zwrot.model):
            punkty += 3

        if self.normalizuj(wydanie.osoba) == self.normalizuj(zwrot.osoba):
            punkty += 2

        if self.normalizuj(wydanie.miejsce) == self.normalizuj(zwrot.miejsce):
            punkty += 1

        try:
            data_wydania = date.fromisoformat(wydanie.data)
            data_zwrotu = date.fromisoformat(zwrot.data)

            if abs((data_wydania - data_zwrotu).days) <= 3:
                punkty += 2
        except ValueError:
            pass

        return punkty

    def znajdz_dopasowania(self, wybrane, zdarzenia):
        if wybrane.typ.casefold() != "wydano":
            return []

        if wybrane.status != "Otwarte":
            return []

        propozycje = []

        for kandydat in zdarzenia:
            if kandydat.id == wybrane.id:
                continue

            if kandydat.status != "Otwarte":
                continue

            if kandydat.typ.casefold() != "zwrócono":
                continue

            if kandydat.kategoria.casefold() != wybrane.kategoria.casefold():
                continue

            wynik = self.punkty(wybrane, kandydat)

            if wynik >= 5:
                propozycje.append((kandydat, wynik))

        propozycje.sort(key=lambda para: (-para[1], para[0].id))
        return propozycje[:3]


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(900, 600)

        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")

        self.tabWidget = QtWidgets.QTabWidget(self.centralwidget)
        self.tabWidget.setGeometry(QtCore.QRect(10, 0, 881, 271))
        self.tabWidget.setObjectName("tabWidget")

        self.tab_5 = QtWidgets.QWidget()
        self.tab_5.setObjectName("tab_5")

        self.cmbTyp = QtWidgets.QComboBox(self.tab_5)
        self.cmbTyp.setGeometry(QtCore.QRect(60, 10, 141, 22))
        self.cmbTyp.setObjectName("cmbTyp")
        self.cmbTyp.addItems(["Wydano", "Zwrócono"])

        self.cmbKategoria = QtWidgets.QComboBox(self.tab_5)
        self.cmbKategoria.setGeometry(QtCore.QRect(140, 50, 201, 21))
        self.cmbKategoria.setObjectName("cmbKategoria")
        self.cmbKategoria.addItems(KATEGORIE)

        self.txtModel = QtWidgets.QLineEdit(self.tab_5)
        self.txtModel.setGeometry(QtCore.QRect(140, 80, 201, 21))
        self.txtModel.setObjectName("txtModel")

        self.label_2 = QtWidgets.QLabel(self.tab_5)
        self.label_2.setGeometry(QtCore.QRect(0, 70, 131, 41))
        self.label_2.setObjectName("label_2")
        self.label_2.setText("Nazwa lub model:")

        self.label = QtWidgets.QLabel(self.tab_5)
        self.label.setGeometry(QtCore.QRect(0, 50, 111, 21))
        self.label.setObjectName("label")
        self.label.setText("Kategoria:")

        self.txtOsoba = QtWidgets.QLineEdit(self.tab_5)
        self.txtOsoba.setGeometry(QtCore.QRect(140, 110, 201, 20))
        self.txtOsoba.setObjectName("txtOsoba")

        self.label_3 = QtWidgets.QLabel(self.tab_5)
        self.label_3.setGeometry(QtCore.QRect(0, 112, 141, 21))
        self.label_3.setObjectName("label_3")
        self.label_3.setText("Osoba odpowiedzialna:")

        self.txtMiejsce = QtWidgets.QLineEdit(self.tab_5)
        self.txtMiejsce.setGeometry(QtCore.QRect(140, 140, 201, 20))
        self.txtMiejsce.setObjectName("txtMiejsce")

        self.label_4 = QtWidgets.QLabel(self.tab_5)
        self.label_4.setGeometry(QtCore.QRect(0, 142, 141, 21))
        self.label_4.setObjectName("label_4")
        self.label_4.setText("Miejsce wydania/zwrotu:")

        self.deData = QtWidgets.QDateEdit(self.tab_5)
        self.deData.setGeometry(QtCore.QRect(140, 170, 201, 22))
        self.deData.setCalendarPopup(True)
        self.deData.setDisplayFormat("dd.MM.yyyy")
        self.deData.setDate(QtCore.QDate.currentDate())
        self.deData.setObjectName("deData")

        self.btnDodaj = QtWidgets.QPushButton(self.tab_5)
        self.btnDodaj.setGeometry(QtCore.QRect(140, 200, 191, 23))
        self.btnDodaj.setObjectName("btnDodaj")
        self.btnDodaj.setText("Dodaj zgłoszenie")

        self.lblKomunikat = QtWidgets.QLabel(self.tab_5)
        self.lblKomunikat.setGeometry(QtCore.QRect(0, 200, 141, 45))
        self.lblKomunikat.setWordWrap(True)
        self.lblKomunikat.setObjectName("lblKomunikat")

        self.label_5 = QtWidgets.QLabel(self.tab_5)
        self.label_5.setGeometry(QtCore.QRect(0, 173, 141, 20))
        self.label_5.setObjectName("label_5")
        self.label_5.setText("Data zdarzenia:")

        self.tabWidget.addTab(self.tab_5, "Dodaj zgłoszenie")

        self.tab_6 = QtWidgets.QWidget()
        self.tab_6.setObjectName("tab_6")

        self.cmbFiltrTyp = QtWidgets.QComboBox(self.tab_6)
        self.cmbFiltrTyp.setGeometry(QtCore.QRect(50, 20, 141, 22))
        self.cmbFiltrTyp.setObjectName("cmbFiltrTyp")
        self.cmbFiltrTyp.addItems(["Wszystkie", "Wydano", "Zwrócono"])

        self.cmbFiltrKategoria = QtWidgets.QComboBox(self.tab_6)
        self.cmbFiltrKategoria.setGeometry(QtCore.QRect(130, 60, 141, 22))
        self.cmbFiltrKategoria.setObjectName("cmbFiltrKategoria")
        self.cmbFiltrKategoria.addItem("Wszystkie")
        self.cmbFiltrKategoria.addItems(KATEGORIE)

        self.cmbFiltrStatus = QtWidgets.QComboBox(self.tab_6)
        self.cmbFiltrStatus.setGeometry(QtCore.QRect(60, 100, 151, 22))
        self.cmbFiltrStatus.setObjectName("cmbFiltrStatus")
        self.cmbFiltrStatus.addItems(["Wszystkie", "Otwarte", "Zamknięte"])

        self.btnFiltruj = QtWidgets.QPushButton(self.tab_6)
        self.btnFiltruj.setGeometry(QtCore.QRect(10, 170, 121, 41))
        self.btnFiltruj.setObjectName("btnFiltruj")
        self.btnFiltruj.setText("Filtruj")

        self.label_6 = QtWidgets.QLabel(self.tab_6)
        self.label_6.setGeometry(QtCore.QRect(30, 60, 111, 21))
        self.label_6.setObjectName("label_6")
        self.label_6.setText("Kategoria:")

        self.btnWyczyscFiltry = QtWidgets.QPushButton(self.tab_6)
        self.btnWyczyscFiltry.setGeometry(QtCore.QRect(140, 170, 121, 41))
        self.btnWyczyscFiltry.setObjectName("btnWyczyscFiltry")
        self.btnWyczyscFiltry.setText("Wyczyść filtry")

        self.btnSzukajDopasowan = QtWidgets.QPushButton(self.tab_6)
        self.btnSzukajDopasowan.setGeometry(QtCore.QRect(720, 30, 141, 41))
        self.btnSzukajDopasowan.setObjectName("btnSzukajDopasowan")
        self.btnSzukajDopasowan.setText("Szukaj dopasowań")

        self.lstDopasowania = QtWidgets.QListWidget(self.tab_6)
        self.lstDopasowania.setGeometry(QtCore.QRect(380, 10, 321, 231))
        self.lstDopasowania.setObjectName("lstDopasowania")

        self.btnZamknijDopasowanie = QtWidgets.QPushButton(self.tab_6)
        self.btnZamknijDopasowanie.setGeometry(QtCore.QRect(720, 100, 141, 41))
        self.btnZamknijDopasowanie.setObjectName("btnZamknijDopasowanie")
        self.btnZamknijDopasowanie.setText("Zamknij dopasowanie")

        self.lblBrakDopasowan = QtWidgets.QLabel(self.tab_6)
        self.lblBrakDopasowan.setGeometry(QtCore.QRect(720, 180, 141, 51))
        self.lblBrakDopasowan.setWordWrap(True)
        self.lblBrakDopasowan.setObjectName("lblBrakDopasowan")

        self.tabWidget.addTab(self.tab_6, "Rejestr i dopasowania")

        self.tblZdarzenia = QtWidgets.QTableWidget(self.centralwidget)
        self.tblZdarzenia.setGeometry(QtCore.QRect(10, 280, 881, 271))
        self.tblZdarzenia.setObjectName("tblZdarzenia")
        self.tblZdarzenia.setColumnCount(8)
        self.tblZdarzenia.setRowCount(0)
        self.tblZdarzenia.setHorizontalHeaderLabels(
            ["ID", "Typ", "Kategoria", "Model", "Osoba", "Miejsce", "Data", "Status"]
        )
        self.tblZdarzenia.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tblZdarzenia.setEditTriggers(QAbstractItemView.NoEditTriggers)

        MainWindow.setCentralWidget(self.centralwidget)

        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)

        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.tabWidget.setCurrentIndex(0)


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.setWindowTitle("Szkolny magazyn — ewidencja sprzętu")
        self.setMinimumSize(900, 600)

        self.repozytorium = RepozytoriumZdarzen(PLIK_DANYCH)
        self.dopasowywacz = Dopasowywacz()

        self._ustaw_widoki()
        self._polacz_sygnaly()
        self.odswiez_tabele()

    def _ustaw_widoki(self):
        self.ui.txtModel.setPlaceholderText("np. Dell Latitude 5420")
        self.ui.txtOsoba.setPlaceholderText("np. Anna Kowalska")
        self.ui.txtMiejsce.setPlaceholderText("np. sala 18")

        tabela = self.ui.tblZdarzenia
        tabela.setEditTriggers(QAbstractItemView.NoEditTriggers)
        tabela.setSelectionBehavior(QAbstractItemView.SelectRows)
        tabela.setSelectionMode(QAbstractItemView.SingleSelection)
        tabela.setAlternatingRowColors(True)
        tabela.horizontalHeader().setStretchLastSection(True)
        tabela.horizontalHeader().setSectionResizeMode(
            QtWidgets.QHeaderView.ResizeToContents
        )

    def _polacz_sygnaly(self):
        self.ui.btnDodaj.clicked.connect(self.dodaj_zgloszenie)
        self.ui.btnFiltruj.clicked.connect(self.zastosuj_filtry)
        self.ui.btnWyczyscFiltry.clicked.connect(self.wyczysc_filtry)
        self.ui.btnSzukajDopasowan.clicked.connect(self.szukaj_dopasowan)
        self.ui.btnZamknijDopasowanie.clicked.connect(
            self.zamknij_dopasowanie
        )

    def dodaj_zgloszenie(self):
        model = self.ui.txtModel.text().strip()
        osoba = self.ui.txtOsoba.text().strip()
        miejsce = self.ui.txtMiejsce.text().strip()
        kategoria = self.ui.cmbKategoria.currentText().strip()

        if not kategoria or kategoria not in KATEGORIE:
            self.ui.lblKomunikat.setText("Wybierz kategorię sprzętu.")
            return

        if not model or not osoba or not miejsce:
            self.ui.lblKomunikat.setText(
                "Uzupełnij model, osobę i miejsce."
            )
            return

        zdarzenie = Zdarzenie(
            id=self.repozytorium.nastepne_id(),
            typ=self.ui.cmbTyp.currentText(),
            kategoria=kategoria,
            model=model,
            osoba=osoba,
            miejsce=miejsce,
            data=self.ui.deData.date().toString("yyyy-MM-dd"),
        )

        try:
            self.repozytorium.dodaj(zdarzenie)
        except OSError as blad:
            self.ui.lblKomunikat.setText(f"Błąd zapisu: {blad}")
            return

        self.ui.lblKomunikat.setText("Dodano zgłoszenie.")
        self.ui.txtModel.clear()
        self.ui.txtOsoba.clear()
        self.ui.txtMiejsce.clear()
        self.odswiez_tabele()

    def zastosuj_filtry(self):
        typ = self.ui.cmbFiltrTyp.currentText()
        kategoria = self.ui.cmbFiltrKategoria.currentText()
        status = self.ui.cmbFiltrStatus.currentText()

        self.odswiez_tabele(
            typ=None if typ == "Wszystkie" else typ,
            kategoria=None if kategoria == "Wszystkie" else kategoria,
            status=None if status == "Wszystkie" else status,
        )

    def wyczysc_filtry(self):
        self.ui.cmbFiltrTyp.setCurrentIndex(0)
        self.ui.cmbFiltrKategoria.setCurrentIndex(0)
        self.ui.cmbFiltrStatus.setCurrentIndex(0)
        self.odswiez_tabele()

    def odswiez_tabele(self, typ=None, kategoria=None, status=None):
        zdarzenia = self.repozytorium.filtruj(
            typ=typ,
            kategoria=kategoria,
            status=status,
        )

        tabela = self.ui.tblZdarzenia
        tabela.setRowCount(len(zdarzenia))

        for wiersz, zdarzenie in enumerate(zdarzenia):
            try:
                data_wyswietlana = datetime.strptime(
                    zdarzenie.data, "%Y-%m-%d"
                ).strftime("%d.%m.%Y")
            except ValueError:
                data_wyswietlana = zdarzenie.data

            wartosci = [
                str(zdarzenie.id),
                zdarzenie.typ,
                zdarzenie.kategoria,
                zdarzenie.model,
                zdarzenie.osoba,
                zdarzenie.miejsce,
                data_wyswietlana,
                zdarzenie.status,
            ]

            for kolumna, wartosc in enumerate(wartosci):
                element = QtWidgets.QTableWidgetItem(wartosc)
                element.setFlags(element.flags() & ~Qt.ItemIsEditable)

                if kolumna == 0:
                    element.setData(Qt.UserRole, zdarzenie.id)

                tabela.setItem(wiersz, kolumna, element)

        tabela.resizeRowsToContents()

    def _zaznaczone_zdarzenie(self):
        tabela = self.ui.tblZdarzenia
        wiersz = tabela.currentRow()

        if wiersz < 0:
            return None

        element = tabela.item(wiersz, 0)

        if element is None:
            return None

        identyfikator = element.data(Qt.UserRole)

        if identyfikator is None:
            try:
                identyfikator = int(element.text())
            except ValueError:
                return None

        return self.repozytorium.znajdz(int(identyfikator))

    def szukaj_dopasowan(self):
        wybrane = self._zaznaczone_zdarzenie()
        lista = self.ui.lstDopasowania
        lista.clear()

        if wybrane is None:
            self.ui.lblBrakDopasowan.setText(
                "Zaznacz zgłoszenie w tabeli."
            )
            return

        if wybrane.typ.casefold() != "wydano":
            self.ui.lblBrakDopasowan.setText(
                "Wybierz zgłoszenie typu „Wydano”."
            )
            return

        if wybrane.status != "Otwarte":
            self.ui.lblBrakDopasowan.setText(
                "Wybrane zgłoszenie jest już zamknięte."
            )
            return

        dopasowania = self.dopasowywacz.znajdz_dopasowania(
            wybrane,
            self.repozytorium.zdarzenia,
        )

        if not dopasowania:
            self.ui.lblBrakDopasowan.setText(
                "Nie znaleziono pasujących zgłoszeń."
            )
            return

        self.ui.lblBrakDopasowan.clear()

        for zwrot, punkty in dopasowania:
            opis = (
                f"ID {zwrot.id} — {zwrot.model}, {zwrot.osoba}, "
                f"{zwrot.miejsce}, {zwrot.data} — {punkty} pkt"
            )
            element = QtWidgets.QListWidgetItem(opis)
            element.setData(Qt.UserRole, zwrot.id)
            lista.addItem(element)

    def zamknij_dopasowanie(self):
        wydanie = self._zaznaczone_zdarzenie()
        element = self.ui.lstDopasowania.currentItem()

        if wydanie is None or element is None:
            self.ui.lblBrakDopasowan.setText(
                "Zaznacz zgłoszenie i propozycję dopasowania."
            )
            return

        zwrot = self.repozytorium.znajdz(int(element.data(Qt.UserRole)))

        if (
            wydanie.status != "Otwarte"
            or zwrot is None
            or zwrot.status != "Otwarte"
        ):
            self.ui.lblBrakDopasowan.setText(
                "To dopasowanie nie jest już dostępne."
            )
            return

        odpowiedz = QMessageBox.question(
            self,
            "Potwierdź dopasowanie",
            f"Czy połączyć zgłoszenia ID {wydanie.id} i ID {zwrot.id} "
            "i oznaczyć je jako zamknięte?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )

        if odpowiedz != QMessageBox.Yes:
            return

        wydanie.status = "Zamknięte"
        zwrot.status = "Zamknięte"

        try:
            self.repozytorium.zapisz()
        except OSError as blad:
            wydanie.status = "Otwarte"
            zwrot.status = "Otwarte"
            QMessageBox.critical(
                self,
                "Błąd zapisu",
                f"Nie udało się zapisać zmian: {blad}",
            )
            return

        self.ui.lstDopasowania.clear()
        self.ui.lblBrakDopasowan.setText("Dopasowanie zamknięto.")
        self.zastosuj_filtry()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    okno = MainWindow()
    okno.show()
    sys.exit(app.exec_())